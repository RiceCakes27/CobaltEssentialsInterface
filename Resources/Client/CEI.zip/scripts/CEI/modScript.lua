load('CEI')
setExtensionUnloadMode('CEI', 'manual')
extensions.core_input_categories.cei = { order = 9999, icon = "settings", title = "CEI", desc = "CEI Controls" } --inject CEI input category at bottom of input categories list
